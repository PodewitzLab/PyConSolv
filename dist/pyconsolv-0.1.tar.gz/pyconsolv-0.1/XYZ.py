class XYZ:
    def __init__(self,db_file):
        '''
        Initialize database of ionic radii from db_file
        
        Parameters:
            - db_file: file that contains the ionic radii for all elements
            
        Class variables:
            - self.db = dictionary which contains element names and corresponding ionic radius
            - self.metalList = list of all metal (as suppoterd by MCPB.py) atomic symbols, used to cross-reference whether element is metal or not
            - self.metals = list of metals detected in the xyz file and the corresponding filename
            - self.ligands = list of non-metal ligands detected in the xyz file and the corresponding filename
        '''
        df = pd.read_csv(db_file,delimiter = '\t')
        self.db = {}
        for A,B in zip(df.values[:,1],df.values[:,5]):
            self.db[A] = B

        self.metalList = ['LI', 'BE', 'F ', 'NA', 'MG', 'AL', 'SI', 'CL', 'K', 'CA', 'SC', 'TI', 'V', 'CR', 'MN', 'FE', 'CO', 'NI', 'CU', 'ZN',
                          'GA', 'GE', 'AS', 'SE', 'BR', 'RB', 'SR', 'Y', 'ZR', 'NB', 'MO', 'TC', 'RU', 'RH', 'PD', 'AG', 'CD', 'IN', 'SN', 'SB',
                          'TE', 'CS', 'BA', 'LA', 'CE', 'PR', 'ND', 'PM', 'SM', 'EU', 'GD', 'TB', 'DY', 'HO', 'ER', 'TM', 'YB', 'YB', 'LU', 'HF',
                          'TA', 'W', 'RE', 'OS', 'IR', 'PT', 'AU', 'HG', 'TL', 'PB', 'BI', 'PO', 'AT', 'FR', 'RA', 'AC', 'TH', 'PA', 'U', 'NP',
                          'PU', 'AM', 'CM', 'BK', 'CF', 'ES', 'FM', 'MD', 'NO', 'LR'] # Metals supported by MCPB
        self.metals = []
        self.ligands = []
        
        
        
    def readXYZ(self,path):
        '''
        Read XYZ (XMOL format) file from path
        
        Parameters:
            - path: location of XYZ file
            
        Class variables:
            - self.coords - [x,3] sized array which contains the coordinates of all atoms in the XYZ file
            - self.atoms - [x] length array which contains aton element labels
        '''
        self.coords = []
        self.atoms = []
        f = open(path,'r')
        counter = 0
        for line in f:
            if (counter < 2):
                counter = counter +1
                continue
            else:
                self.atoms.append(line.split()[0])
                self.coords.append(line.split()[1:])
        f.close()
        self.coords = np.asarray(self.coords, dtype=float)
        self.atoms = np.asarray(self.atoms)
        
        
    def calculateDistanceMatrix(self):
        '''
        Calculate distances between each atom pair
        
        Parameters:
            
        Class variables:
            - self.Dmat - [x,x] shaped array which contains the pair distances
            - self.Amat - [x,x] shaped array which contains the pair elements
        '''
        self.Dmat = np.empty((self.coords.shape[0],self.coords.shape[0]))
        self.Amat = np.empty((self.coords.shape[0],self.coords.shape[0]), dtype = '<U5') #<U is better for string frmatting due to less compatibility issues
        for i in range(self.coords.shape[0]):
            for j in range(self.coords.shape[0]):
                self.Dmat[i][j] = np.linalg.norm(self.coords[i]-self.coords[j])
                self.Amat[i][j] = self.atoms[i]+'-'+self.atoms[j]
                
    def generateAdjacencyMatrix(self):
        '''
        Check whether atoms are connected to eachother; atoms are considered bonded, based on ionic radius from http://crystalmaker.com/support/tutorials/atomic-radii/index.html
        
        Parameters:
            
        Class variables:
            - self.Adjmat - [x,x] shaped array which contains information about bonding, where 1 means bonded, 0 means unbonded
        '''
        self.Adjmat = np.zeros(self.Dmat.shape)
        for i in range(self.Dmat.shape[0]):
            for j in range(self.Dmat.shape[1]):
                a = self.Amat[i][j].split('-')
                dist = self.db[a[0]] + self.db[a[1]]
                if (i==j):
                    continue
                if (self.Dmat[i][j] <= dist*0.6):
                    self.Adjmat[i][j] = 1
                    
    def generateLinkList(self):
        '''
        Check whether atoms are connected to eachother; atoms are considered bonded, based on ionic radius from http://crystalmaker.com/support/tutorials/atomic-radii/index.html
        
        Parameters:
            
        Class variables:
            - self.linkList - list containing lists of partners for each atom
        '''          
                    
        self.linkList = []      
        for i in range(self.Dmat.shape[0]):
            temp =[]
            for j in range(self.Dmat.shape[1]):
                a = self.Amat[i][j].split('-')
                dist = self.db[a[0]] + self.db[a[1]]
                if (i==j):
                    continue
                if (self.Dmat[i][j] <= dist*0.6):
                    temp.append(j)
            self.linkList.append(temp)
        
    def connectedCompponents(self):
        '''
        DFS algorithm for finding components
        
        Parameters:
            
        Class variables:
            - self.connected - list which stores elements of each subgraph
            - self.chain - [x] length array which contains the chain number to which each atom belongs
        '''
        visited = []
        self.connected = []
        for i in range(len(self.linkList)):
            visited.append(0)
        for i in range(len(self.linkList)):
            if visited[i] == 0:
                temp = []
                self.connected.append(self.DFSaux(i, temp, visited))
        for elem in self.connected:
            elem.sort()
        
    
    def DFSaux(self, vertex, temp, visited):
        '''
        Auxiliary helper function to perform DFS 
        
        Parameters:
            
        Class variables:
        
        '''
        visited[vertex] = 1
        temp.append(vertex)
        for i in self.linkList[vertex]:
            if visited[i] == 0:
                temp = self.DFSaux(i, temp, visited)
        return temp
    
    def assignChain(self):
        '''
        Assign each atom to a chain
        
        Parameters:
            
        Class variables:
            - self.chain - contains the chain ID of each atom
        '''
        temp = []
        for i in range(len(self.connected)):
            for j in range(len(self.connected[i])):
                temp.append([self.connected[i][j],i])
        self.chain = np.array(temp)
        self.chain = self.chain[np.lexsort((self.chain[:,0],self.chain[:,1]))]
    
    def createPDB(self,Res = [], Chain = [], ResSN = []):
        '''
        Create a file following PDB format standards
        
        Parameters:
            
        Class variables:
            - self.files - List of lists containing PDB data for each molecule
        '''
        self.files = []
        
        for e in range(len(self.connected)):
            file = []
            atoms = len(self.connected[e])
            
            for i in range(atoms):
                
                atom_pos = self.connected[e][i]

                line = ''
                atom = 'HETATM'
                line = line+atom # Col 1-6 Identifier HETATM
                
                atomSN = [' ',' ',' ',' ',' '] #col 7-11 Atom Serial Number
                SN = str(i+1)
                if len(SN) > 5:
                    print('Serial Number is too long for atom %d!' %i)
                for j in range(len(SN)):
                    atomSN[4-j]=SN[-(j+1)]
                string = ''
                string = string.join(atomSN)
                line = line+string

                line = line+' ' # Col 12 is empty

                if len(self.atoms[atom_pos]) > 4:
                    print('Atom name is too long for atom %d!' %i)
                atomName = [' ',' ',' ',' '] #col 13-16 Atom Name
                for j in range(len(self.atoms[atom_pos])):
                    atomName[j]=self.atoms[atom_pos][j]
                string = ''
                string = string.join(atomName)
                line = line+string

                line = line+' ' # Col 17 is alternate location indicator

                line = line+' '+' '+chr(65+e) # Col 18-20 Residue Name

                line = line+' ' # Col 21 is empty

                line = line+str(e+1) # Col 22 Chain ID

                line = line+' '+' '+' ' + str(e+1) #col 23-26 Residue sequence Number - Integer

                line = line+' ' # Col 27 for insertions of residues

                line = line+' '+' '+' ' # Col 28-30 are empty

                x = [' ',' ',' ',' ',' ',' ',' ',' '] #col 31-38 Residue sequence Number - real (8.3)
                x_data = str(self.coords[atom_pos][0].round(3))
                if len(x_data) == 0:
                    print('x data is missing for atom %d!' %i)
                for j in range(len(x_data)):
                    x[7-j]=x_data[-(j+1)]
                string = ''
                string = string.join(x)
                line = line+string

                y = [' ',' ',' ',' ',' ',' ',' ',' '] #col 39-46 Residue sequence Number - real (8.3)
                y_data = str(self.coords[atom_pos][1].round(3))
                if len(y_data) == 0:
                    print('y data is missing for atom %d!' %i)
                for j in range(len(y_data)):
                    y[7-j]=y_data[-(j+1)]
                string = ''
                string = string.join(y)
                line = line+string

                z = [' ',' ',' ',' ',' ',' ',' ',' '] #col 47-54 Residue sequence Number - real (8.3)
                z_data = str(self.coords[atom_pos][2].round(3))
                if len(z_data) == 0:
                    print('z data is missing for atom %d!' %i)
                for j in range(len(z_data)):
                    z[7-j]=z_data[-(j+1)]
                string = ''
                string = string.join(z)
                line = line+string

                oc = [' ',' ','1','.','0','0'] #col 55-60 Occupancy - real (6.2)
                string = ''
                string = string.join(oc)
                line = line+string

                tf = [' ',' ','0','.','0','0'] #col 61-66 Temperature Factor - real (6.2)
                string = ''
                string = string.join(tf)
                line = line+string

                line = line+' '+' '+' '+' '+' '+' ' # Col 67-72 are empty

                line = line+' '+' '+' '+' ' # Col 73-76 Segment identifier

                if len(self.atoms[atom_pos]) > 2:
                    print('Element Symbol is too long for atom %d!' %i)
                es = [' ',' '] #col 77-78 Element Symbol
                for j in range(len(self.atoms[atom_pos])):
                    es[1-j]=self.atoms[atom_pos][-(j+1)]
                string = ''
                string = string.join(es)
                line = line+string

                line = line+'\n'

                file.append(line)
            file.append('TER\n')
            self.files.append(file)

    def writePDBFiles(self, path):
        '''
        Write out PDB files
        
        Parameters:
            - path - file output path
            
        Class variables:
            - self.filenames - contains the names of the PDB files which are written out
            - self.path - path where pdb files are generated
        '''
        self.filenames = []
        self.path = path + '/'
        
        atomid = 0
        for i in range(len(self.files)):
            if len(self.files[i]) == 2: # single atom ligands need to be treated differently to work with MCPB.py
                name = self.files[i][0].split()[-1].upper()
                self.filenames.append(name+'.pdb')
                f=open(self.path+'/'+name+'.pdb','w')
                if self.isMetal(name) == True:
                    s = self.files[i][0][:7]+'{:>4}'.format(1)+' '+'{:<5}'.format(name) + '{:>3}'.format(name)+ self.files[i][0][20:]
                    f.write(s.upper())
                    f.write('TER')
                    f.close()
                    self.metals.append([name+'.pdb', name])
                else:
                    f.write(self.files[i][0][:7]+'{:>4}'.format(1)+' '+'{:<5}'.format(name) + '{:>3}'.format(name)+ self.files[i][0][20:])
                    f.write('TER')
                    f.close()
                    self.ligands.append([name+'.pdb', name])
                
            else: 
                self.filenames.append(chr(65+i)+'.pdb')
                f=open(path+'/'+chr(65+i)+'.pdb','w')
                for line in self.files[i]:
                    if 'TER' in line:
                        f.write('END')
                    else:
                        atomid += 1
                        f.write(line[:7]+'{:>4}'.format(atomid)+' '+'{:<5}'.format(line[11:16].strip()+str(atomid))+ line[17:])
                f.close()
                self.ligands.append([chr(65+i)+'.pdb', chr(65+i)])
        tmp = []
        atomid = 0
        for i in range(len(self.filenames)):
            f = open(path+'/'+self.filenames[i],'r')
            for line in f:
                if 'TER' in line:
                    continue
                elif 'END' in line:
                    continue
                else:
                    atomid += 1
                    tmp.append(line[:7]+'{:>4}'.format(atomid)+ line[11:])
            f.close()
        f = open(path+'/'+ 'Full_PDB.pdb','w')
        for i in range(len(tmp)):
            f.write(tmp[i])
        f.write('END')
        f.close()
        
    def writeMol2Files(self, path):
        '''
        Write out mol2 files
        
        Parameters:
            - path - I/O file output path
            
        Class variables:
            - self.charges = charges for each fragment, read from chargeMap.dat
        '''
        
        print('Reading charges from {}\n'.format(self.path+'chargeMap.dat'))
        
        self.charges = []
        self.molNotCreated = []
        f = open(self.path+'/chargeMap.dat','r')
        for line in f:
            self.charges.append(line.split())
        f.close()
        atomid = 0
        for i in range(len(self.files)):
            
            print(self.charges[i])
            if len(self.files[i]) == 2: # single atom ligands need to be treated differently to work with MCPB.py
                name = self.files[i][0].split()[-1].upper()
                if self.isMetal(name) == True:
                    print('Metal atom found: {}, assigning charge {}'.format(name, self.charges[i][1]))
                coords = self.files[i][0].split()[6:9]
                self.createMol2_new(name,coords=coords, charge = float(self.charges[i][1]))
            else:
                self.molNotCreated.append(self.charges[i])
        
    def createMol2_new(self,name,coords,charge=-1):
        '''
        Write out mol2 file for metal and single atom ligands
        
        Parameters:
            - name: name of the mol2 file
            - coords: coordinates of atoms
            - charge: charge of atom
                    
        Class variables:
        '''
        
        
        layout = '''@<TRIPOS>MOLECULE
{:<3}
1 0 1 0 0
SMALL
USER_CHARGES


@<TRIPOS>ATOM
1 {:<2}        {:>.4f}    {:>.4f}    {:>.4f}   {:<2}    1  {:>2} {:>.4f}
@<TRIPOS>BOND
@<TRIPOS>SUBSTRUCTURE
  1 {:<2}    1 TEMP 0 **** **** 0 ROOT
'''
        print('Writing out {} ... \n'.format(self.path + name +'.mol2'))
        f = open(self.path + name +'.mol2','w')
        f.write(layout.format(name,name,float(coords[0]),float(coords[1]),float(coords[2]),name,name,charge,name))
        f.close()
        
    def createFinalMol2(self, path):
        '''
        Create final mol2 files for tleap, using the charges from the RESP calculation
        
        Parameters:
            - path = folder where files are located/created
        Class variables:
        
        '''
        self.readRESP(path+'/orca_calculations')
        self.readMAP(path + '/MCPB_setup')
        iterator = 0 # keeps track of current atom id
        for name in self.filenames:
            switch  = 0
            tmp = []
            fname = name.split('.')[0]
            fin = open(self.path+'/'+fname+'.mol2','r') # read mol2 files corresponding to the pdb files
            fout = open(self.path+'/'+fname+'1.mol2','w') # create new mol2 file
            for line in fin:
                if 'USER_CHARGES' in line:
                    fout.write('RESP Charge\n')
                elif '@<TRIPOS>ATOM' in line:
                    switch = 1
                    fout.write(line)
                elif '@<TRIPOS>BOND' in line:
                    fout.write(line)
                    switch = 2
                elif '@<TRIPOS>SUBSTRUCTURE' in line:
                    fout.write(line)
                    switch = 3
                elif '@<TRIPOS>MOLECULE' in line:
                    fout.write(line)
                    switch = 4
                else:
                    if switch == 1:
                        
                        tmp_line = line.split()[:-1] # remove old charge
                        
                        tmp_line.append(float(self.charges[iterator][-1])) # add resp charge
                        tmp_line[-2] = fname+'1'
                        tmp_line[5] = self.map[iterator][-1]
                        
                        fout.write('{:>7} {:<7}    {:>7}    {:>7}    {:>7}   {:<2}    {}  {:>2} {:>9.6f}\n'.format(*tmp_line))
                        iterator += 1
                    elif switch == 3:
                        fout.write('     1 {}         1 TEMP              0 ****  ****    0 ROOT\n'.format(fname+'1'))
                        switch = 0
                    elif switch == 4:
                        fout.write(fname+'1\n')
                        switch = 0
                    else:
                        if 'bcc' in line:
                            fout.write(line.replace('bcc','RESP Charge'))
                        else:
                            fout.write(line.replace('ar','1'))
            fout.close()
            fin.close()
    
    def readRESP(self, path):
        '''
        Read RESP charges generated by Multiwfn and saved in orca_freq.molden.chg
        
        Parameters:
            - path = path to where charge file is located
            
        Class variables:
            - self.charges = contains the RESP charges generated by Multiwfn
        '''
        f = open(path+'/freq/orca_freq.molden.chg','r')
        self.charges = []
        iterator = 0
        for line in f:
            iterator += 1
            self.charges.append([iterator ,line.split()[0],line.split()[-1]])
        f.close()
    
    def readMAP(self,path):
        '''
        Read Map generated by MCPB for atom types from fingerprint
        
        Parameters:
            - path = path to where map file is located
            
        Class variables:
            - self.map = contains the mapping for atom types and id
        '''
        f = open(path+'/LIG_standard.fingerprint','r')
        self.map = []
        iterator = 0
        for line in f:
            iterator += 1
            self.map.append([iterator ,line.split()[0],line.split()[-1]])
        f.close()
    
    def isMetal(self, string):
        '''
        checks if given string is a metal element or not
        
        Parameters:
            - string = string to check
            
        Class variables:
            
        Returns:
            - Bool - True if string is metal, False if it is not
        '''
        if string.upper() in self.metalList:
            return True
        else:
            return False
    
    def prepareMCPB(self, inputfile):
        '''
        Runs main PDB generation functionality of the XYZ class.
        
        Parameters:
            - inputfile = full path to xyz inputfile
            
        Class variables:
        '''
        path = '/'.join(inputfile.split('/')[:-1])
        self.readXYZ(inputfile)
        self.calculateDistanceMatrix()
        self.generateAdjacencyMatrix()
        self.generateLinkList()
        self.connectedCompponents()
        self.assignChain()
        self.createPDB()
        self.writePDBFiles(path)
